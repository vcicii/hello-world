package jspservlet.vo;

public class Cart {
	private String UserID;
	private String prodname;
	private int aomunt = 0;
	private int prodprice = 0;
	private String ProdPic;
	private int allprice = 0;
	
	public String getUserID() {
		return UserID;
	}
	public void setUserID(String userID) {
		UserID = userID;
	}
	public String getProdname() {
		return prodname;
	}
	public void setprodname(String prodname) {
		this.prodname = prodname;
	}
	public int getAomunt() {
		return aomunt;
	}
	public void setAomunt(int aomunt) {
		this.aomunt = aomunt;
	}
	
	public int getPrice() {
		return prodprice;
	}
	public void setPrice(int price) {
		this.prodprice = price;
	}
	
	public String getProdPic() {
		return ProdPic;
	}
	public void setProdPic(String prodPic) {
		ProdPic = prodPic;
	}
	
	public int getAllPrice() {
		return allprice;
	}
	public void setAllPrice() {
		this.allprice = this. aomunt * this.prodprice;
	}
}
