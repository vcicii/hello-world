package jspservlet.vo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jspservlet.db.DBConnect;

public class Product {
	private String ProdID;
	private String ProductName;
	private int price;           //3000
	private String ProdSize;       //10*30*20
	private String ProdInf;        //used to ...
	private String ProdPic;
	private String ProdCompose;    //chip...
	private int ProdNumber;      //100
	private String ProdComment;    //good
	
	public String getProdID() {
		return ProdID;
	}
	public void setProdID(String ProdID) {
		this.ProdID = ProdID;
	}
	
	public String getProductName() {
		return ProductName;
	}
	public void setProductName(String productName) {
		this.ProductName = productName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getProdSize() {
		return ProdSize;
	}
	public void setProdSize(String prodSize) {
		ProdSize = prodSize;
	}
	public String getProdInf() {
		return ProdInf;
	}
	public void setProdInf(String prodInf) {
		ProdInf = prodInf;
	}
	public String getProdPic() {
		return ProdPic;
	}
	public void setProdPic(String prodPic) {
		ProdPic = prodPic;
	}
	public String getProdCompose() {
		return ProdCompose;
	}
	public void setProdCompose(String prodCompose) {
		ProdCompose = prodCompose;
	}
	public int getProdNumber() {
		return ProdNumber;
	}
	public void setProdNumber(int prodNumber) {
		ProdNumber = prodNumber;
	}
	public String getProdComment() {
		return ProdComment;
	}
	public void setProdComment(String prodComment) {
		ProdComment = prodComment;
	}

}

