package jspservlet.servlet;

import java.awt.List;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jspservlet.dao.ProductDAO;
import jspservlet.dao.impl.ProductDAOImpl;
import jspservlet.vo.Product;



public class ShowByNameServlet extends HttpServlet{
	public void doGet(HttpServletRequest req, HttpServletResponse res)
		    throws IOException, ServletException{
		 }
		
		
		 public void doPost(HttpServletRequest req, HttpServletResponse res)
				    throws IOException, ServletException{
			 
			 		 System.out.println("i am in show by name java(dopost)");
					 Product product = new Product();
					 product.setProductName(req.getParameter("prodname"));
					 ArrayList<Product> plist=new ArrayList<Product>();
					 ProductDAO dao=new ProductDAOImpl();
					 
					 try {
						 plist=dao.queryByProductName(product);
						  
					 }catch(Exception e) {
						 e.printStackTrace();
					 }
					// System.out.println("cong yi fan"+plist.size());
					 System.out.println("i am in show by name java(dopost)");
					 req.setAttribute("product_list",plist);//灏唋ist闆嗗悎鏁版嵁鏀惧叆鍒皉equest涓叡浜�
					 req.getRequestDispatcher("/testprodlist.jsp").forward(req, res);
					
				 }
		 
		 
		 
}
