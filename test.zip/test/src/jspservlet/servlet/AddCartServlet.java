package jspservlet.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jspservlet.dao.AddCartDAO;
import jspservlet.dao.impl.AddCartDAOImpl;
import jspservlet.vo.Product;
import jspservlet.vo.User;

public class AddCartServlet extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException{
		this.doPost(req, res);
		}
		public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException{
			
			User user = new User();
			Product product = new Product();
			AddCartDAO dao = new AddCartDAOImpl();
			
			HttpSession session=req.getSession();
			user.setUsername((String)session.getAttribute("username"));
			user.setUserID((String)session.getAttribute("userID"));
		
			
			if(user.getUsername() == null) {
				res.sendRedirect("./login.jsp");
			}
			System.out.println("userid:"+user.getUserID());
			System.out.println("userNum:"+req.getParameter("qtybutton"));
			int amount = 0;
			amount=Integer.valueOf(req.getParameter("qtybutton"));						
					
			product.setProdID((String)session.getAttribute("ProdID"));
			product.setProdNumber(Integer.valueOf(req.getParameter("qtybutton")));
			
			System.out.println("prodid:"+product.getProdID());
			
			try {
				dao.userAddCart(user, product);
				
//				System.out.println("11111");
//				System.out.println(user.getUsername());
//				System.out.println(product.getProductName());
				
			}catch (Exception e) {
				//
				e.printStackTrace();
			}
		}

}
