package jspservlet.servlet;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jspservlet.dao.RegiDAO;
import jspservlet.dao.UserDAO;
import jspservlet.dao.impl.RegiDAOImpl;
import jspservlet.dao.impl.UserDAOImpl;
import jspservlet.vo.User;

public class RegiServlet extends HttpServlet {
	
	public void doGet(HttpServletRequest req, HttpServletResponse res)
		throws IOException, ServletException{
			}
	public void doPost(HttpServletRequest req, HttpServletResponse res)
		throws IOException, ServletException{
			User user = new User();
			user.setUsername(req.getParameter("username"));
			user.setPassword(req.getParameter("password"));
			user.setPhoneNumber(Integer.valueOf(req.getParameter("phoneNumber")));
			user.setAddress(req.getParameter("address"));
			user.setEmail(req.getParameter("email"));
			
			//create the userID by time
			Date d = new Date();
			DateFormat sdf3 = new SimpleDateFormat("yyyyMMddHHmmss");
			String s = "U"+sdf3.format(d);
			user.setUserID(s);
			
			RegiDAO dao = new RegiDAOImpl();
			int flag = 1;
			try {
				flag = dao.queryByRegiUsername(user);
			}catch (Exception e) {
				//
				e.printStackTrace();
			}
			if(flag == 1) {//��ע��ɹ�
				HttpSession session=req.getSession();
				session.setAttribute("username", user.getUsername());
				session.setAttribute("userID", user.getUserID());
				res.sendRedirect("./welcome.jsp");
			} else {
				res.sendRedirect("./existRegi.jsp");
			}
		}
}
