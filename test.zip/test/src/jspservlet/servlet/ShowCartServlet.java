package jspservlet.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jspservlet.dao.CartDAO;

import jspservlet.dao.impl.ShowCartDAOImpl;
import jspservlet.vo.Cart;
import jspservlet.vo.Product;
import jspservlet.vo.User;

public class ShowCartServlet extends HttpServlet{
	public void doGet(HttpServletRequest req, HttpServletResponse res)
		    throws IOException, ServletException{
		System.out.println("this is showcartservlet GET");
		this.doPost(req,res);
		 }
		
		 public void doPost(HttpServletRequest req, HttpServletResponse res)
		    throws IOException, ServletException{
			
			 User user = new User();
			 HttpSession session=req.getSession();
			 user.setUsername((String)session.getAttribute("username"));
			 user.setUserID((String)session.getAttribute("userID"));
			 
			 
			 if(user.getUserID()==null) {
					res.sendRedirect("./login.jsp");
				
			 }else {
				 
				 System.out.println("this is showcartservlet post");
				 ArrayList<Cart> clist=null;
				 CartDAO dao=new ShowCartDAOImpl();
				 try {
					 System.out.println("??????");
					 System.out.println("user id is "+user.getUserID());
					 clist=dao.showCart(user.getUserID());//��clistΪ�ա���
					 System.out.println("MMMMMMMMM");	
					 
				 }catch(Exception e) {
					 e.printStackTrace();
				 }
				 
				 System.out.println("lxylxy");	
				 
				 System.out.println(clist.size());
				
					 req.setAttribute("clist",clist);
					 req.getRequestDispatcher("/cart.jsp").forward(req, res);
				 
				 
				
				 
			 }
					
			 
			 
			
		 }
	
	
	
	
}
