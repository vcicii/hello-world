package jspservlet.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jspservlet.dao.ProductDAO;
import jspservlet.dao.impl.ProductDAOImpl;
import jspservlet.vo.Product;

public class ShowAProductServlet extends HttpServlet{
	public void doGet(HttpServletRequest req, HttpServletResponse res)
		    throws IOException, ServletException{
		System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!");
		this.doPost(req,res);
		 }
		
		 public void doPost(HttpServletRequest req, HttpServletResponse res)
		    throws IOException, ServletException{
			 Product product = new Product();
			 Product newp=new Product();
			 product.setProductName((String)req.getParameter("name"));
			 System.out.println(product.getProductName());
			 ProductDAO dao=new ProductDAOImpl();
			 try {
				 System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!");
				 newp=dao.showByProductName(product);
				  
			 }catch(Exception e) {
				 e.printStackTrace();
			 }

			 System.out.println(newp.getProductName());
			 req.setAttribute("product",newp);
			 
			 //lxy test
			 HttpSession session=req.getSession();
			 session.setAttribute("ProdID", newp.getProdID());
			 
			 req.getRequestDispatcher("/test.jsp").forward(req, res);
			
		 }
	
}
