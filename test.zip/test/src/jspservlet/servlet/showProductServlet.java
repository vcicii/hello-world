package jspservlet.servlet;

import java.awt.List;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jspservlet.dao.ProductDAO;
import jspservlet.dao.impl.ProductDAOImpl;
import jspservlet.vo.Product;



public class showProductServlet extends HttpServlet{
	public void doGet(HttpServletRequest req, HttpServletResponse res)
		    throws IOException, ServletException{
			
			this.doPost(req, res);
		 }
		
		 public void doPost(HttpServletRequest req, HttpServletResponse res)
		    throws IOException, ServletException{
			 Product product = new Product();
			 ArrayList<Product> plist=new ArrayList<Product>();
			 ProductDAO dao=new ProductDAOImpl();
			 try {
				 plist=dao.showAllProduct();
				  
			 }catch(Exception e) {
				 e.printStackTrace();
			 }

			 System.out.println(plist.size());
			 req.setAttribute("product_list",plist);
			 ////
			 req.getRequestDispatcher("/testprodlist.jsp").forward(req, res);
			
		 }
		 
		 
		 
		 
		 
}