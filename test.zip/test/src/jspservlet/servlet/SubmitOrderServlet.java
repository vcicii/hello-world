package jspservlet.servlet;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import jspservlet.dao.SubmitOfferDAO;

import jspservlet.dao.impl.SubmitOfferDAOImpl;

import jspservlet.vo.User;

public class SubmitOrderServlet extends HttpServlet{
	public void doGet(HttpServletRequest req, HttpServletResponse res)
		    throws IOException, ServletException{
		
			this.doPost(req, res);
			//System.out.println("this is SubmitOrderServlet GET");

		 }
		
		 public void doPost(HttpServletRequest req, HttpServletResponse res)
		    throws IOException, ServletException{
			User user = new User();//��ǰ��¼���û�
							 
			HttpSession session=req.getSession();
			user.setUsername((String)session.getAttribute("username"));
			user.setUserID((String)session.getAttribute("userID"));
			
			System.out.println(user.getUserID());
			
			String[] productname=req.getParameterValues("productname");//Ҫ��Ĳ�Ʒ////////////////
			 
			int amountProd = 0;
			
			amountProd = Integer.valueOf(req.getParameter("qtybutton1"));//////////����Ӧ��������
			
			System.out.println("lxy print " + amountProd + " hhh");
			
			int flag = 0;
			if(productname == null) {
				flag = 0;
			}else {
				flag = 1;
				for(int i = 0;i<productname.length;i++) {///
					 System.out.println(productname[i]);
					 System.out.println("lxy print " + amountProd + " hhh");
				}	
			}
			
					 
			 
			Date d = new Date();
			DateFormat sdf3 = new SimpleDateFormat("yyyyMMddHHmmss");
			String offerID = "O"+sdf3.format(d);//����ID

			SubmitOfferDAO dao=new SubmitOfferDAOImpl();
			
			
			try {
				if(flag == 1) {
					dao.SubmitOffer(productname, user, offerID, amountProd);
					res.sendRedirect("./welcome.jsp");
				}
				else {
					res.sendRedirect("./error.jsp");
				}
								
				
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//���������impl���� �Ȳ���offerings  �ٲ���trade
			 
			
			 
			 
		 }

}
