package jspservlet.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jspservlet.dao.TestImageDAO;
import jspservlet.dao.impl.TestImageDAOImpl;
import jspservlet.vo.Product;

public class TestImageServlet extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse res)
		throws IOException, ServletException{
	}
	public void doPost(HttpServletRequest req, HttpServletResponse res)
		throws IOException, ServletException{
			
			Product product = new Product();
			product.setProductName("prod1");
			TestImageDAO dao = new TestImageDAOImpl();
			String pic = null;
		
		try {
			pic = dao.testImage(product);
		}catch (Exception e) {
			//
			e.printStackTrace();
		}
		
		HttpSession session=req.getSession();
		session.setAttribute("pic", pic);
		
		res.sendRedirect("./testimage.jsp");
	}
}
