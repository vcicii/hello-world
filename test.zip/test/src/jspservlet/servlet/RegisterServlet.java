package jspservlet.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RegisterServlet extends HttpServlet {
	
	public void doGet(HttpServletRequest req, HttpServletResponse res)
		throws IOException, ServletException{
		}
	public void doPost(HttpServletRequest req, HttpServletResponse res)
		throws IOException, ServletException{
		
			try {
				
			}catch (Exception e) {
				//
				e.printStackTrace();
			}
			res.sendRedirect("./register.jsp");
		}
}
