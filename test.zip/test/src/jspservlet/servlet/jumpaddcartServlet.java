package jspservlet.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jspservlet.vo.Product;
import jspservlet.vo.User;

public class jumpaddcartServlet extends HttpServlet {


	public void doGet(HttpServletRequest req, HttpServletResponse res)
		throws IOException, ServletException{
	}
	public void doPost(HttpServletRequest req, HttpServletResponse res)
		throws IOException, ServletException{
			/////�˴�Ӧ����֪prodID ��username
			User user = new User();
			Product product = new Product();
			user.setUsername("ann");
			product.setProductName("prod1");
			
			//String prodID = "prod1";
			//String username = "ann";
			
			try {
				HttpSession session=req.getSession();
				session.setAttribute("prodID", product.getProductName());
				res.sendRedirect("./addcart.jsp");
			}catch (Exception e) {
				e.printStackTrace();
			}
	}
}
