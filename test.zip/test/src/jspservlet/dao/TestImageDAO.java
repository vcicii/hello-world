package jspservlet.dao;

import jspservlet.vo.Product;

public interface TestImageDAO {
	public String testImage(Product product) throws Exception;
}
