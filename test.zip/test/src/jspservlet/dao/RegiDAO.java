package jspservlet.dao;
import jspservlet.vo.User;

public interface RegiDAO {
	public int queryByRegiUsername(User user) throws Exception;
}
