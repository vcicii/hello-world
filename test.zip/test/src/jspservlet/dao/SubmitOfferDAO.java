package jspservlet.dao;

import jspservlet.vo.User;

public interface SubmitOfferDAO {
	public void SubmitOffer(String[] productname,User user,String offerID,int amountProd) throws Exception;
}
