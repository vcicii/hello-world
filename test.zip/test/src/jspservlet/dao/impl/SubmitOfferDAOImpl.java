package jspservlet.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jspservlet.dao.SubmitOfferDAO;
import jspservlet.db.DBConnect;
import jspservlet.vo.User;

public class SubmitOfferDAOImpl implements SubmitOfferDAO{

	public void SubmitOffer(String[] productname, User user, String offerID, int amountProd) throws Exception {
		System.out.println(user.getUserID());
		
//		for(int i = 0;i<productname.length;i++) {
//			 System.out.println(productname[i]);
//		 }
		
		System.out.println(offerID);
		/////////////////////////////////////////////////////
		String sql = "INSERT INTO `javawebdblxy`.`offerings` (`offerID`, `userID`) VALUES (?, ?)";
		String sql1= "select * from cart where prodid= ?";
		String sql3= "insert into trade values(?,?,?)";
		String sql4= "select * from product where productname= ?";
		String sql5= "DELETE FROM `javawebdblxy`.`cart` WHERE (`userID` = ?) and (`prodID` = ?)";
		String sql6 ="UPDATE `javawebdblxy`.`offerings` SET `totalpay` = ? WHERE (`offerID` = ?)";
		PreparedStatement pstmt = null ;
        PreparedStatement pstmt1 = null ;
        PreparedStatement pstmt2 = null ;
        PreparedStatement pstmt3 = null ;
        PreparedStatement pstmt5 = null ;
		DBConnect dbc = null;
		
		try {
			//�������ݿ�
			 dbc = new DBConnect() ;   
	         pstmt = dbc.getConnection().prepareStatement(sql) ;	         	
	         pstmt.setString(1,offerID); 
	         pstmt.setString(2,user.getUserID());
	        // pstmt.setInt(3,6299) ;//////////////////////////////////
	         
	         pstmt.executeUpdate();
	         pstmt.close();
	         dbc.close() ; 
	         dbc = new DBConnect() ;
	         int allPrice = 0;
	         
	         for(int i = 0; i<productname.length;i++) {
	    	
		    	 pstmt1 = dbc.getConnection().prepareStatement(sql4) ; 
		    	 pstmt1.setString(1,productname[i]);
		    	 ResultSet rs = pstmt1.executeQuery();
		    	 rs.next();
		    	 String prodid=rs.getString("prodid");
		    	 int prodprice = rs.getInt("prodprice");
		    	 
		    	 
		    	 
		    	 pstmt2 = dbc.getConnection().prepareStatement(sql1) ; 		    	 
		    	 pstmt2.setString(1,prodid);
		    	 ResultSet rs1 = pstmt2.executeQuery();
		    	 rs1.next();	    	 
		    	 
		    	 int amount=rs1.getInt("aomunt");
		    	 String userID=rs1.getString("userID");
		    	 
		    	 allPrice = allPrice +prodprice*amount;
		    	 
		    	 pstmt2 = dbc.getConnection().prepareStatement(sql3) ;/////
	
		         pstmt2.setString(1,offerID); 
		         pstmt2.setString(2,prodid);
		         pstmt2.setInt(3,amount) ;	          
		         pstmt2.executeUpdate();
		         
		         //after add to order,delete the prod in cart
		         System.out.println("wwwww  " + userID);//
		    	 System.out.println("yyy  " + prodid);//
		         pstmt5 = dbc.getConnection().prepareStatement(sql5) ; 
		         pstmt5.setString(1, userID);
		         pstmt5.setString(2, prodid);
		         pstmt5.executeUpdate();
		         
		         
		         pstmt1.close();
		         pstmt2.close();
		         pstmt5.close();
		         rs.close();
		         rs1.close();
		    	 
		     }
	         
	         //���¶������
	         pstmt3 = dbc.getConnection().prepareStatement(sql6) ;
	         pstmt3.setString(2,offerID);
	         pstmt3.setInt(1,allPrice);
	         pstmt3.executeUpdate();
	         pstmt3.close();
	         
	         
	         
		}catch (SQLException e) {
    		System.out.println(e.getMessage()); 
    	}finally {
    		// �ر����ݿ�����   
            dbc.close() ; 
    	}
		
	}

}
