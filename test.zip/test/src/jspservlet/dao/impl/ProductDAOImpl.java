package jspservlet.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import jspservlet.dao.ProductDAO;
import jspservlet.db.DBConnect;
import jspservlet.vo.Product;

public class ProductDAOImpl implements ProductDAO {
	
	public Product showByProductName(Product product) throws Exception {
		String sql = "select * from Product where ProductName= ?";
        PreparedStatement pstmt = null ;   
        DBConnect dbc = null;   
        try{      
            dbc = new DBConnect() ;   
            pstmt = dbc.getConnection().prepareStatement(sql) ; 
            pstmt.setString(1,product.getProductName()) ;   
            
            ResultSet rs = pstmt.executeQuery();
            System.out.println(product.getProductName());
            
            while(rs.next()){
            product.setProdID(rs.getString("prodID"));
        	product.setProductName(rs.getString("ProductName"));
        	product.setPrice(rs.getInt("ProdPrice"));
        	product.setProdInf(rs.getString("ProdInfo"));
        	product.setProdSize(rs.getString("ProdSize"));
        	product.setProdCompose(rs.getString("ProdCompose"));
        	product.setProdPic(rs.getString("ProdPic"));
            }
            System.out.println(product.getProductName());
            rs.close() ; //�رս����
            pstmt.close() ;   //�رվ��
        }catch (SQLException e){   
            System.out.println(e.getMessage());   
        }finally{   
            dbc.close() ;   //�ر����ݿ�
        }   
		return product;
		
	}
	public ArrayList<Product> queryByProductName(Product product) throws Exception {
		String sql = "select * from Product where ProductName Like ?";
        PreparedStatement pstmt = null ;   
        DBConnect dbc = null;   
        ResultSet rs =null;
        ArrayList<Product> plist = new ArrayList<Product>();
        try{      
            dbc = new DBConnect() ;   
            pstmt = dbc.getConnection().prepareStatement(sql) ; 
            pstmt.setString(1,'%'+product.getProductName()+'%') ;   
            
            rs = pstmt.executeQuery();
  
            while(rs.next()){
            	Product prod=new Product();
            	prod.setProductName(rs.getString("ProductName"));
            	prod.setPrice(rs.getInt("ProdPrice"));
            	prod.setProdInf(rs.getString("ProdInfo"));
            	prod.setProdSize(rs.getString("ProdSize"));
            	prod.setProdCompose(rs.getString("ProdCompose"));
            	prod.setProdPic(rs.getString("ProdPic"));
            	plist.add(prod);
            	
            }
            
            rs.close() ; //�رս����
            pstmt.close() ;   //�رվ��
        }catch (SQLException e){   
            System.out.println(e.getMessage());   
        }finally{   
            dbc.close() ;   //�ر����ݿ�
        }   
		return plist;
		
	}

	public ArrayList<Product> showAllProduct() throws Exception {
		String sql = "select * from Product";
        PreparedStatement pstmt = null ;   
        DBConnect dbc = null;   
        ResultSet rs=null;
        ArrayList<Product> plist = new ArrayList<Product>();
		try{      
            dbc = new DBConnect() ;   
            pstmt = dbc.getConnection().prepareStatement(sql) ;  
            rs = pstmt.executeQuery();
  
            while(rs.next()){
				 Product product=new Product();
				 product.setProductName(rs.getString("ProductName"));
				 product.setPrice(rs.getInt("ProdPrice"));
				 product.setProdInf(rs.getString("ProdInfo"));
				 product.setProdSize(rs.getString("ProdSize"));
				 product.setProdCompose(rs.getString("ProdCompose"));
				 product.setProdPic(rs.getString("ProdPic"));
				 
				 plist.add(product);
				 
			 }
    
            rs.close() ; //�رս����
            pstmt.close() ;   //�رվ��
        }catch (SQLException e){   
            System.out.println(e.getMessage());   
        }finally{   
            dbc.close() ;   //�ر����ݿ�
        }

        return plist;
	}
}