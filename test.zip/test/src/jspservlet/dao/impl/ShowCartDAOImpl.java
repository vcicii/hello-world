package jspservlet.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import jspservlet.dao.CartDAO;
import jspservlet.db.DBConnect;
import jspservlet.vo.Cart;
import jspservlet.vo.Product;

public class ShowCartDAOImpl implements CartDAO {

	public ArrayList<Cart> showCart(String userid) throws Exception {
		String sql1= "select * from cart where userid= ?";
		String sql2="select * from product where prodid=?";
        PreparedStatement pstmt1 = null ;
        PreparedStatement pstmt2 = null ; 
        DBConnect dbc = null;   
        System.out.println("AAAAAAAA");
        ArrayList<Cart> clist = new ArrayList<Cart>();
        ArrayList<String> pnamelist = new ArrayList<String>();
        try{      
            dbc = new DBConnect() ;   
            pstmt1 = dbc.getConnection().prepareStatement(sql1) ; 
            pstmt1.setString(1,userid);
            ResultSet rs1 = pstmt1.executeQuery();
            
            while(rs1.next()){
            	System.out.println("BBBBBBBBBB");
            	
            	String prodID = rs1.getString("prodid");
            	
            	System.out.println(prodID);
            	
            	pstmt2 = dbc.getConnection().prepareStatement(sql2);
            	
            	pstmt2.setString(1, prodID);
            	
            	ResultSet rs2 = pstmt2.executeQuery();
            	rs2.next();
            	System.out.println("CCCCCCCCCC");
            	String pname=rs2.getString("productname");
            	System.out.println(pname);
            	pnamelist.add(pname);
            	
            	
            	Cart cart=new Cart();
            	
            	cart.setAomunt(rs1.getInt("aomunt"));
            	cart.setprodname(rs2.getString("productname"));
            	cart.setPrice(rs2.getInt("prodprice"));
            	cart.setProdPic(rs2.getString("prodpic"));            	
            	
            	clist.add(cart);
            	rs2.close() ;
            	pstmt2.close();

            	
            }
           
            System.out.println("size= " + pnamelist.size());
            
            rs1.close();
            pstmt1.close();
                    }catch (SQLException e){   
            System.out.println(e.getMessage());   
        }finally{   
            dbc.close();
        } 
        System.out.println("DDDDDDDD");
              
		return clist;
	}


}
