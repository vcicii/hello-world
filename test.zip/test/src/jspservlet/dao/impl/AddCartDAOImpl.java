package jspservlet.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jspservlet.dao.AddCartDAO;
import jspservlet.db.DBConnect;
import jspservlet.vo.Product;
import jspservlet.vo.User;

public class AddCartDAOImpl implements AddCartDAO {

	public void userAddCart(User user, Product product) throws Exception{
		
		String sql ="insert into Cart values(?,?,?)";
		String sql1 ="select * from cart where userID = ? and prodID = ?";
		String sql2 ="UPDATE `javawebdblxy`.`cart` SET `aomunt` = ? WHERE (`userID` = ?) and (`prodID` = ?)";
		//String sql2 =""
		PreparedStatement pstmt = null ;
		PreparedStatement pstmt1 = null ;
		PreparedStatement pstmt2 = null ;
		DBConnect dbc = null;
		int flag = 1;
		int existNum = 0;
		int allNum = 0;
			
		// ������������ݿ�ľ������ 
		try {
			//�������ݿ�
			 dbc = new DBConnect() ;   
	         pstmt = dbc.getConnection().prepareStatement(sql) ;
	         pstmt1 = dbc.getConnection().prepareStatement(sql1) ;
	         pstmt2 = dbc.getConnection().prepareStatement(sql2) ;
	         
	         //�жϣ������ﳵ�����и���Ʒ����ԭ�������ϼ�
	         pstmt1.setString(1,user.getUserID()); 
	         pstmt1.setString(2,product.getProdID());
	         ResultSet rs = pstmt1.executeQuery();
	         
	         while(rs.next()) {
	        	 flag = 0;
	        	 existNum = rs.getInt("aomunt");
	         }
	         
	         if(flag == 0) {//��������
	        	 allNum = existNum + product.getProdNumber();
	        	 pstmt2.setInt(1,allNum) ;
	        	 pstmt2.setString(2,user.getUserID()); 
		         pstmt2.setString(3,product.getProdID());
		                  
		         pstmt2.executeUpdate();
	         }else {
	        	  //�����ݿ���д������
		         pstmt.setString(1,user.getUserID()); 
		         pstmt.setString(2,product.getProdID());
		         pstmt.setInt(3,product.getProdNumber()) ;
		                  
		         pstmt.executeUpdate();
		          
	         }
	         pstmt.close() ;
	         pstmt1.close() ;
	         pstmt2.close() ;
	         rs.close();
		}catch (SQLException e) {
    		System.out.println(e.getMessage()); 
    	}finally {
    		// �ر����ݿ�����   
            dbc.close() ; 
    	}
		
	}
}
