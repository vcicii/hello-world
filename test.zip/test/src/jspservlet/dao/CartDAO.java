package jspservlet.dao;

import java.util.ArrayList;

import jspservlet.vo.Cart;
import jspservlet.vo.Product;

public interface CartDAO {
	public ArrayList<Cart> showCart(String userid) throws Exception;
}
