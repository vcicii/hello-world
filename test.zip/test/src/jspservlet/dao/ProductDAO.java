package jspservlet.dao;

import java.sql.ResultSet;
import java.util.ArrayList;

import jspservlet.vo.Product;

public interface ProductDAO {
	public ArrayList<Product> queryByProductName(Product product) throws Exception;
	public ArrayList<Product> showAllProduct() throws Exception;
	public Product showByProductName(Product product) throws Exception;
}