package jspservlet.dao;

import jspservlet.vo.Product;
import jspservlet.vo.User;

public interface AddCartDAO {
	
	public void userAddCart(User user, Product product) throws Exception;
}
